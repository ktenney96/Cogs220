---
layout: example
title: Histogram Null Values Example
permalink: /examples/histogram-null-values/index.html
spec: histogram-null-values
image: /examples/img/histogram-null-values.png
---

This example demonstrates a [histogram](../histogram) over a numerical range, with a segment to show the prevalence of null values.

{% include example spec=page.spec %}
