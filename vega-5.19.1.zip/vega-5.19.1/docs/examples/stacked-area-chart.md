---
layout: example
title: Stacked Area Chart Example
permalink: /examples/stacked-area-chart/index.html
spec: stacked-area-chart
image: /examples/img/stacked-area-chart.png
---

A stacked area chart depicts the sum of series of quantitative values using layered areas, while still enabling inspection of individual series.

{% include example spec=page.spec %}
