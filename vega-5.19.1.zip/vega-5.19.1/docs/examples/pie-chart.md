---
layout: example
title: Pie Chart Example
permalink: /examples/pie-chart/index.html
spec: pie-chart
image: /examples/img/pie-chart.png
---

A pie chart encodes proportional differences among a set of numeric values as the angular extent and area of a circular slice.

{% include example spec=page.spec %}
