export {
  domCanvas as domCanvas,
  domCanvas as canvas,
  domImage as image
} from './src/domCanvas';
