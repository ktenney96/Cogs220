export {default as selector} from './src/event-selector';
