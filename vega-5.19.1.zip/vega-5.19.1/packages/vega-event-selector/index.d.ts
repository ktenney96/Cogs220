export function selector(selectorName: string, source: string): any[];
