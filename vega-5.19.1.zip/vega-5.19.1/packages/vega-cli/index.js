module.exports = require('vega');
